package com.example.sholatjadwalpengingat.api;

public class ApiUrl {
    public static final String URL_ROOT_HTTP ="https://muslimsalat.com/";
}
