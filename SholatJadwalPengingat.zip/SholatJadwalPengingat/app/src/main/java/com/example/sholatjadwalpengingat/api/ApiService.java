package com.example.sholatjadwalpengingat.api;

import com.example.sholatjadwalpengingat.model.JadwalSholat;

import retrofit2.Call;
import retrofit2.http.GET;
public interface ApiService {
    @GET("banyuwangi.json")
    Call<JadwalSholat> getJadwal();
}
