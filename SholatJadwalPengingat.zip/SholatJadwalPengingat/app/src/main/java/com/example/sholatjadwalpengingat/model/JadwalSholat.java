package com.example.sholatjadwalpengingat.model;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class JadwalSholat {

    @SerializedName("items")
    @Expose
    private List<Item> items = null;
    @SerializedName("city")
    @Expose
    private String city;
    public String getCity() {
        return city;
    }


    public List<Item> getItems() {
        return items;
    }



}